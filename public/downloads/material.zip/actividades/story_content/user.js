function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5am0q33zEfz":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

